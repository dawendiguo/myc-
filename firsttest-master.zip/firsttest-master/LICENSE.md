#include<iostream>
using namespace std;
int main()
{
	cout>>"this is my firsttest!">>endl;
}
