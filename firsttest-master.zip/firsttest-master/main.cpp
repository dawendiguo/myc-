#include"class.h"
int main()
{ Student c1(12 "test" f);
c1.display();
return 0;
}
